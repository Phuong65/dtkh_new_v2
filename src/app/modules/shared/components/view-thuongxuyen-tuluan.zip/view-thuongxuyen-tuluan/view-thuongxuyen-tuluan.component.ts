import { NotificationService } from '@core/services/notification.service';
import { Component, Input, OnChanges, OnInit, SimpleChanges } from '@angular/core';
import { CoursePlanActivityTuluan } from '@modules/shared/models/course-plan-activity-tuluan';
import { ElnKhoaHoc } from '@modules/shared/models/elng-khoa-hoc';

@Component( {
	selector: 'app-view-thuongxuyen-tuluan',
	templateUrl: './view-thuongxuyen-tuluan.component.html',
	styleUrls: [ './view-thuongxuyen-tuluan.component.css' ]
} )
export class ViewThuongxuyenTuluanComponent implements OnInit, OnChanges {
	
	countChanges = 0;
	
	@Input() tuluan: CoursePlanActivityTuluan;
	
	@Input() courseSelected: ElnKhoaHoc;

	selectedTuluan: CoursePlanActivityTuluan;


	constructor (
		private notificationService: NotificationService,
	) {

	}

	ngOnChanges ( changes: SimpleChanges ): void {
		if ( changes[ 'tuluan' ] ) {
			this.selectedTuluan = this.tuluan;
			++this.countChanges;
		}
	}

	ngOnInit (): void {

	}

}
